using Microsoft.VisualStudio.TestTools.UnitTesting;
using Person;

namespace Person;

[TestClass] 
public class UnitTest1
{
    [TestMethod]
    public void CheckNameGetterSetterShouldBeJeff()
    {
        //setup
        var p = new Person();
        //arrange
        p.Name = "Jeff";
        //assert
        Assert.AreEqual("Jeff", p.Name);
    }
    [TestMethod]
    public void CheckNameGetterSetterShouldNotBeJeff()
    {
        //setup
        var p = new Person();
        //arrange
        p.Name = "James";
        //assert
        Assert.AreNotEqual("Jeff", p.Name);
    }
    [TestMethod]
    public void CheckAgeGetterSetterShouldBe30()
    {
        //setup
        var p = new Person();
        //arrange
        p.Age = 30;
        //assert
        Assert.AreEqual(30, p.Age);
    }
    [TestMethod]
    public void CheckAgeGetterShouldNotBe30()
    {
        //setup
        var p = new Person();
        //arrange
        p.Age = 5;
        //assert
        Assert.AreNotEqual(30, p.Age);
    }
    [TestMethod]
    public void CheckJobGetterSetterShouldBeSoftwareEngineer()
    {
        //setup
        var p = new Person();
        //arrange
        p.Job = "Software Engineer";
        //assert
        Assert.AreEqual("Software Engineer", p.Job);
    }
    [TestMethod]
    public void CheckJobGetterSetterShouldNotBeSoftwareEngineer()
    {
        //setup
        var p = new Person();
        //arrange
        p.Job = "Engineer";
        //assert
        Assert.AreNotEqual("Software Engineer", p.Job);
    }
    [TestMethod]
    public void CheckHeightGetterSetterShouldBe6point0()
    {
        //setup
        var p = new Person();
        //arrange
        p.Height = 6.0;
        //assert
        Assert.AreEqual(6.0, p.Height);
    }
    [TestMethod]
    public void CheckHeightGetterSetterShouldNotBe6point0()
    {
        //setup
        var p = new Person();
        //arrange
        p.Height = 4.0;
        //assert
        Assert.AreNotEqual(6.0, p.Height);
    }

    //test
}
