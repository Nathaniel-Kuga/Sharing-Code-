﻿namespace Person;
public class Person : IPerson
{
    public string Name { get; set; }
    public int Age { get; set; }
    public string Job { get; set; }
    public double Height { get; set; }
}